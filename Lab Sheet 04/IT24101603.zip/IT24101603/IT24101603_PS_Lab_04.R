getwd()
setwd("C:\\Users\\IT24101603\\Desktop\\IT24101603")

branch_data <- read.csv("Exercise.txt", header=TRUE)

fix(branch_data)
attach(branch_data)

#Branch - Catogorical, Nominal
#Sales_X1 - Numerical Continuous, Ratio
#Advertising_X2 - Numerical Continuous, Ratio
#Years_X3 - Numerical Discrete, Ratio

boxplot(Sales_X1, main = "Box Plot for Sales", 
        outline = TRUE, 
        outpch = 8, 
        horizontal = TRUE)

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

get.outliers <- function(z)
{
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", lb))
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
  
}

get.outliers(Years_X3)

